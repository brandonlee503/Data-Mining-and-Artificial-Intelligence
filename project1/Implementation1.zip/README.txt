Run the setup.sh bash script to compile

Requires python virtual environment
if you don't already have it installed run

pip install virtualenv
